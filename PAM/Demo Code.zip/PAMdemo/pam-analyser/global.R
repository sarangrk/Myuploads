################################ LOAD LIBRARIES ################################

library(dygraphs)
library(visNetwork)

# print(.libPaths())
if(!require(shiny))       {install.packages('shiny', dependencies = TRUE);require(shiny)}
if(!require(shinydashboard)) {install.packages('shinydashboard', dependencies = TRUE);require(shinydashboard)}
if(!require(ggplot2))     {install.packages('ggplot2', dependencies = TRUE);require(ggplot2)}
if(!require(plotly))      {install.packages('plotly', dependencies = TRUE);require(plotly)}
if(!require(rpivotTable)) {devtools::install_github(c("ramnathv/htmlwidgets", "smartinsightsfromdata/rpivotTable"))}

if(!require(gplots))      {install.packages('gplots', dependencies = TRUE);require(gplots)}
if(!require(plyr))        {install.packages('plyr', dependencies = TRUE);require(plyr)}
if(!require(dplyr))       {install.packages('dplyr', dependencies = TRUE);require(dplyr)}
if(!require(lubridate))   {install.packages('lubridate', dependencies = TRUE);require(lubridate)}
if(!require(gridExtra))   {install.packages('gridExtra', dependencies = TRUE);require(gridExtra)}
if(!require(stringr))     {install.packages('stringr', dependencies = TRUE);require(stringr)}
if(!require(survival))    {install.packages('survival', dependencies = TRUE);require(survival)}
if(!require(grid))        {install.packages('grid', dependencies = TRUE);require(grid)}
if(!require(ROCR))        {install.packages('ROCR', dependencies = TRUE);require(ROCR)}
if(!require(caret))       {install.packages('caret', dependencies = TRUE);require(caret)}
if(!require(e1071))       {install.packages('e1071', dependencies = TRUE);require(e1071)}
if(!require(aws.s3))      {install.packages('aws.s3', dependencies = TRUE);require(aws.s3)}
if(!require(devtools))    {install.packages('devtools', dependencies = TRUE);require(devtools)}
if(!require(rms))         {install.packages('rms', dependencies = TRUE);require(rms)}
if(!require(xtable))      {install.packages('xtable', dependencies = TRUE);require(xtable)}
if(!require(cowplot))     {install.packages('cowplot', dependencies = TRUE);require(cowplot)}
if(!require(DT))          {install.packages('DT', dependencies = TRUE);require(DT)}
# leaflet maps

if(!require(leaflet))      {install.packages('leaflet');require(leaflet)}
if(!require(RColorBrewer)) {install.packages('RColorBrewer');require(RColorBrewer)}
if(!require(scales))       {install.packages('scales');require(scales)}
if(!require(lattice))      {install.packages('lattice');require(lattice)}
if(!require(stringr))      {install.packages('stringr');require(stringr)}

# Install GBM Packages and other training packages
if(!require(randomForestSRC)) {install.packages('randomForestSRC', dependencies = TRUE); require(randomForestSRC)}
if(!require(pec)) {install.packages('pec', dependencies = TRUE); require(pec)}
if(!require(lazyeval)) {install.packages('lazyeval', dependencies = TRUE); require(lazyeval)}



#### Get AWS S3 Access #####
Sys.setenv("AWS_ACCESS_KEY_ID" = Sys.getenv("AWS_ACCESS_KEY_ID"),
           "AWS_SECRET_ACCESS_KEY" = Sys.getenv("AWS_SECRET_ACCESS_KEY"))



#### Set up global dataset and models for use in training/prediction ####
# Datasets
global_dataset <<- reactiveValues() # Global dataset that stores raw and processed data
validation_forecast <<- NULL # Stores model forecasts from data fit
test_forecast <<- NULL # Stores model forecasts from data fit
survival <- list() # Subset of data for BI style reporting
# 
# df<- readRDS('/users/am250152/Desktop/test.csv')
# colnames(df)[colnames(df)=="Identifier"] <- "asset_id"
# df = tidyr::separate(data=df,
#                      col=Location.1,
#                      into=c("latitude", "longitude"),
#                      sep=",",
#                      remove=FALSE)
# 
# #clean and process data
# df$latitude <- stringr::str_replace_all(df$latitude, "[(]", "")
# df$longitude <- stringr::str_replace_all(df$longitude, "[)]", "")
# df$latitude <- as.numeric(df$latitude)
# df$longitude <- as.numeric(df$longitude)
# 
# map_data<-df

# Survival models to be fit
survival_models <<- reactiveValues(linear=NULL, rf=NULL, dt=NULL,
                                   linear_complete=FALSE, rf_complete=FALSE, dt_complete=FALSE)
initial_models <<- c("Random Forest"="Random Forest", "Cox Regression"="Cox Regression", "Decision Tree"="Decision Tree")
models_to_build <<-  reactiveValues(list = initial_models)

### Functions ##################################################################
## Set Tab Page Names ##
results_tab <- function() {
  "results_page"
}

pareto_tab <- function() {
  "pareto_page"
}

failure_profile_tab <- function() {
  "failures_page"
}

optimise_tab <- function(){
  "optimisation_page"
}

## Default value functions ##
default_cost_unplanned_failure <- function(){
  return(5000)
}

## Check datasets ##
validationForecastReady <- function(){
  if(is.null(validation_forecast))
    return(FALSE)
  if(!"completed" %in% colnames(validation_forecast))
    return(FALSE)
  return(validation_forecast[1, "completed"])
}

## Check global_dataset ready ##
globalDataReady <- function(){
  length(global_dataset$processed) > 0
}

fitted_model <- function(selected_model){
  if(selected_model == "Decision Tree"){
    return(survival_models$dt)
  } else if (selected_model == "Random Forest") {
    return(survival_models$rf)
  } else {
    return(survival_models$linear)
  }
}

# Grab correct predictions from validation set
validationSuffix <- function(selected_model)({
  if(selected_model == "Decision Tree"){
    return("Predict_ST_")
  } else if (selected_model == "Random Forest") {
    return("Predict_SRF_")
  } else {
    return("Predict_SL_")
  }
})

models_available <- function(){
  return(models_to_build)
}

global_data_load_message <- function(page = 'Introduction') {
  if (page == 'Introduction')
    showNotification(tags$div(p('Go to the "Load Data" tab.'), p('You need load some data before this app becomes fully functional.')), type="error", closeButton = TRUE)
}

## Attributes and formula ##
attributes_to_exclude <- function() {
  return(c('survival_time', 'event_occurred','asset_id', 'event_id', 'installed_date',
           'event_type', 'planned', 'end_date', 'latitude', 'longitude', 'start_date', 'event_date',
           'failure_year', 'failure_month'))
}

attributes_to_exclude_user <<- reactiveValues(list=c())

attributes_for_modelling <- function(data, ignore.user = FALSE) {
  attribs <- colnames(data)
  attribs <- attribs[!attribs %in% attributes_to_exclude()]
  if (!ignore.user) {
    attribs <- attribs[!attribs %in% attributes_to_exclude_user$list]
  }
  return(attribs)
}

get_model_formula <- function(attributes_to_use) {
  as.formula(paste('Surv(survival_time, event_occurred) ~ ', paste0(attributes_to_use, collapse=" + ")))
}

## Attributes for partitioning ##
attributes_for_partitioning <- function(data) {
  cnames <- colnames(data)
  cnames <- cnames[!cnames %in% c('survival_time', 'event_occurred', 'installed_date',
                                  'end_date', 'latitude', 'longitude', 'start_date', 'event_date')]
  c('NONE', cnames)
}

## DATA UPLOAD ##
get_s3_datasets <- function(){
  # bucket <- get_bucket(bucket = 'dslab-data', prefix = 'pam_demo',
  #                      secret = Sys.getenv("AWS_SECRET_ACCESS_KEY"), key = Sys.getenv("AWS_ACCESS_KEY_ID"))
  # datasets <- c()
  # for (item in bucket) {
  #   # search for folders, only one level below the pam_demo folder
  #   if (!endsWith(item$Key, '/')) next
  #   if (str_count(item$Key, "/") != 2) next
  #
  #   datasets <- c(datasets, (gsub('/$', '', gsub('^[^/]*/', '', item$Key))))
  # }
  datasets <- c()
  return(datasets)
}

get_s3_dataset_attribute_files <- function(dataset_name){
  # dsprefix <- paste0('pam_demo/',dataset_name)
  # bucket <- get_bucket(bucket = 'dslab-data', prefix = dsprefix,
  #                      secret = Sys.getenv("AWS_SECRET_ACCESS_KEY"), key = Sys.getenv("AWS_ACCESS_KEY_ID"))
  #
  # datasets <- vector(mode="list")
  # i_dataset = 1
  # dsnames <- c()
  # for (item in bucket) {
  #   # search for csv files
  #   if (!endsWith(item$Key, '.csv')) next
  #
  #   name <- gsub('^pam_demo/+[^/]*/+', '', item$Key)
  #   name <- gsub('\\.csv$', '', name)
  #   if (startsWith(name, 'asset_attribute_data_')) {
  #     name <- gsub('^asset_attribute_data_', '', name)
  #     dsnames <- c(dsnames, name)
  #   }
  # }
  dsnames <- c()
  return(dsnames)
}

get_s3_dataset <- function(dataset_name){
  # dsprefix <- paste0('pam_demo/',dataset_name)
  # bucket <- get_bucket(bucket = 'dslab-data', prefix = dsprefix,
  #                      secret = Sys.getenv("AWS_SECRET_ACCESS_KEY"), key = Sys.getenv("AWS_ACCESS_KEY_ID"))
  #
  # datasets <- vector(mode="list")
  # i_dataset = 1
  # dsnames <- c()
  #
  # withProgress(message="Downloading Data", value = 0, {
  #   for (item in bucket) {
  #     # search for csv files
  #     if (!endsWith(item$Key, '.csv')) next
  #
  #     name <- gsub('^pam_demo/[^/]*/', '', item$Key)
  #     name <- gsub('\\.csv$', '', name)
  #     dsnames <- c(dsnames, name)
  #
  #     obj <- get_object(bucket = 'dslab-data', object = item$Key,
  #                       secret = Sys.getenv("AWS_SECRET_ACCESS_KEY"), key = Sys.getenv("AWS_ACCESS_KEY_ID"))
  #
  #     datasets[[i_dataset]] <- read.csv(text = rawToChar(obj))
  #     i_dataset <- i_dataset + 1
  #     incProgress(1/length(bucket))
  #   }
  # })
  # names(datasets) <- dsnames
  datasets <- c()
  return(datasets)
}

get_nice_dataset_name <- function(dataset_name){
  return(gsub('[_-]', ' ', dataset_name))
}

## LEAFLET FUNCTIONS ##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length=n+1)
  hcl(h=hues, l=65, c=100)[1:n]
}

## Survival Object Functions ##
survivalObjReady <- function(){
  return(length(survival$completed) > 0)
}

createSurvivalFrame <- function(f_survfit){
  # initialise frame variable
  f_frame <- NULL
  # check if more then one strata
  if(length(names(f_survfit$strata)) == 0){
    # create data.frame with data from survfit
    f_frame <- data.frame(time=f_survfit$time, n.risk=f_survfit$n.risk, n.event=f_survfit$n.event, n.censor = f_survfit
                          $n.censor, surv=f_survfit$surv, upper=f_survfit$upper, lower=f_survfit$lower)
    # create first two rows (start at 1)
    f_start <- data.frame(time=c(0, f_frame$time[1]), n.risk=c(f_survfit$n, f_survfit$n), n.event=c(0,0),
                          n.censor=c(0,0), surv=c(1,1), upper=c(1,1), lower=c(1,1))
    # add first row to dataset
    f_frame <- rbind(f_start, f_frame)
    # remove temporary data
    rm(f_start)
  }
  else {
    # create vector for strata identification
    f_strata <- NULL
    for(f_i in 1:length(f_survfit$strata)){
      # add vector for one strata according to number of rows of strata
      f_strata <- c(f_strata, rep(names(f_survfit$strata)[f_i], f_survfit$strata[f_i]))
    }
    # create data.frame with data from survfit (create column for strata)
    f_frame <- data.frame(time=f_survfit$time, n.risk=f_survfit$n.risk, n.event=f_survfit$n.event, n.censor = f_survfit
                          $n.censor, surv=f_survfit$surv, upper=f_survfit$upper, lower=f_survfit$lower, strata=factor(f_strata))
    # remove temporary data
    rm(f_strata)
    # create first two rows (start at 1) for each strata
    for(f_i in 1:length(f_survfit$strata)){
      # take only subset for this strata from data
      f_subset <- subset(f_frame, strata==names(f_survfit$strata)[f_i])
      # create first two rows (time: 0, time of first event)
      f_start <- data.frame(time=c(0, f_subset$time[1]), n.risk=rep(f_survfit[f_i]$n, 2), n.event=c(0,0),
                            n.censor=c(0,0), surv=c(1,1), upper=c(1,1), lower=c(1,1), strata=rep(names(f_survfit$strata)[f_i],
                                                                                                 2))
      # add first two rows to dataset
      f_frame <- rbind(f_start, f_frame)
      # remove temporary data
      rm(f_start, f_subset)
    }
    # reorder data
    f_frame <- f_frame[order(f_frame$strata, f_frame$time), ]
    # rename row.names
    rownames(f_frame) <- NULL
  }
  # return frame
  return(f_frame)
}


#' set_panel_size
#'
#' @param p ggplot2
#' @param g gtable
#' @param file optional output filename
#' @param margin grid unit
#' @param width grid unit, requested panel width
#' @param height grid unit, requested panel height
#'
#' @importFrom grid unit convertWidth convertHeight
#' @return gtable with fixed panel sizes
#' @export
#' @examples
#' p1 <- qplot(mpg, wt, data=mtcars, colour=cyl)
#' p2 <- p1 + facet_wrap(~carb, nrow=1)
#' grid.arrange(grobs=lapply(list(p1,p2), set_panel_size))
set_panel_size <- function(p=NULL, g=ggplotGrob(p), file=NULL,
                           margin = unit(1,"mm"),
                           width=unit(4, "cm"),
                           height=unit(4, "cm")){

  panels <- grep("panel", g$layout$name)
  # panel_index_w<- unique(g$layout$l[panels])
  panel_index_h<- unique(g$layout$t[panels])
  # nw <- length(panel_index_w)
  nh <- length(panel_index_h)

  if(getRversion() < "3.3.0"){

    # the following conversion is necessary
    # because there is no `[<-`.unit method
    # so promoting to unit.list allows standard list indexing
    # g$widths <- grid:::unit.list(g$widths)
    g$heights <- grid:::unit.list(g$heights)

    # g$widths[panel_index_w] <-  rep(list(width),  nw)
    g$heights[panel_index_h] <- rep(list(height), nh)

  } else {

    # g$widths[panel_index_w] <-  rep(width,  nw)
    g$heights[panel_index_h] <- rep(height, nh)

  }

  if(!is.null(file))
    ggsave(file, g,
           # width = convertWidth(sum(g$widths) + margin,
           # unitTo = "in", valueOnly = TRUE),
           height = convertHeight(sum(g$heights) + margin,
                                  unitTo = "in", valueOnly = TRUE))

  g
}


################################# LOAD MODULES #################################

my_modules <- list.files("tabs", pattern = "tab_module.R", full.names = TRUE,
                         recursive = TRUE)

for(my_module in my_modules) source(my_module)




#########Data Prep#########

df_custom <- readRDS("C:/Backup/R_directory/sample_data.rds")

df_custom <- df_custom[1:30,]

df_custom$Group <- rep(c("A","B","C"),10)

df_custom$Color <- rep(c("#0000FF", "#FF0000"), 15)

x = rnorm(30)

# normalize
min.x = min(x)
max.x = max(x)

x.norm = (x - min.x)/(max.x - min.x + 1)

df_custom["FailureProbability"] <- x.norm 
df_custom <- df_custom[order(-df_custom$FailureProbability),]

type <- c("Radiator Failure","Axle Failure","Brake Failure","Light Failure","Engine Failure","Tire Failure")
freq <- as.numeric(c(175, 143, 110, 80, 74,67))

defects <- data.frame(type, freq)


defects <- arrange(defects, freq) %>%
  mutate(
    cumsum = cumsum(freq),
    temp = round(freq / sum(freq), 3),
    cum_freq = cumsum(temp)
  )
