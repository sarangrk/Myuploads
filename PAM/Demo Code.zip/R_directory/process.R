library(shiny)
library(leaflet)
library(dplyr)
library(tidyr)
library(tidyverse)

setwd("C:\\Users\\teradata\\Desktop\\R_directory")

#load data
df = read.csv("./NYPD_7_Major_Felony_Incidents.csv", stringsAsFactors = FALSE)
df = tidyr::separate(data=df,
                     col=Location.1,
                     into=c("Latitude", "Longitude"),
                     sep=",",
                     remove=FALSE)



#clean and process data
df$Latitude <- stringr::str_replace_all(df$Latitude, "[(]", "")
df$Longitude <- stringr::str_replace_all(df$Longitude, "[)]", "")
df$Latitude <- as.numeric(df$Latitude)
df$Longitude <- as.numeric(df$Longitude)

sample_data <- df[c(1:1000),]
saveRDS(sample_data, "./sample_data.rds")

