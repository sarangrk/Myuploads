
#' Defaults for the model management functions
.MMoptions <- list(cores = 1, #parallel::detectCores() - 1,
                   serialize_models = FALSE,
                   serialize_feature_engineering_models = TRUE)
