library(testthat)
library(dmmfR)

test_check("dmmfR")
